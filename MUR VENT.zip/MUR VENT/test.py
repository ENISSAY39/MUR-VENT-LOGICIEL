import tkinter as tk
from tkinter import ttk
import json
import random
import threading
import time

class GVMControlApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Contrôle GVM - Mode de Contrôle")
        self.root.geometry("900x900")  # Format carré
        
        # Configuration
        self.grid_size = 3  # Taille de la grille (8x8 cellules)
        self.cell_size = 30
        self.fan_status = {}
        self.publish_cell = 24
        self.initialize_fan_data()
        
        # Style
        self.configure_styles()
        
        # Interface
        self.create_control_interface()
        
        # Thread de mise à jour
        self.update_thread = threading.Thread(target=self.update_rpm_data, daemon=True)
        self.update_thread.start()
    
    def configure_styles(self):
        """Configure les styles visuels"""
        style = ttk.Style()
        style.configure('TFrame', background='#f0f0f0')
        style.configure('Title.TLabel', font=('Helvetica', 16, 'bold'), background='#f0f0f0')
        style.configure('Control.TFrame', borderwidth=2, relief='groove')
        style.configure('Cell.TLabelframe', borderwidth=1, relief='solid')
        style.configure('Cell.TLabelframe.Label', font=('Helvetica', 8))
    
    def initialize_fan_data(self):
        """Initialise les données des ventilateurs"""
        for cell_row in range(1, self.grid_size + 1):
            for cell_col in range(1, self.grid_size + 1):
                cell_id = f"{cell_row}{cell_col}"
                self.fan_status[cell_id] = {
                    'power': [0] * 9,  # 9 ventilateurs par cellule
                    'rpm': [0] * 9,
                    'active': False,
                    'functional': True
                }
    
    def create_control_interface(self):
        """Crée l'interface de contrôle carrée"""
        main_frame = ttk.Frame(self.root, padding=10)
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Titre
        ttk.Label(main_frame, text="Mode de Contrôle - Réglage Puissance (%)", 
                 style='Title.TLabel').pack(pady=10)
        
        # Conteneur principal carré
        square_container = ttk.Frame(main_frame)
        square_container.pack(expand=True)
        
        # Grille des cellules (8x8)
        self.create_square_grid(square_container)
        
        # Contrôles en bas
        control_frame = ttk.Frame(main_frame)
        control_frame.pack(fill=tk.X, pady=15)
        
        # Sélection de puissance
        ttk.Label(control_frame, text="Puissance (%):").grid(row=0, column=0, padx=5)
        self.power_var = tk.IntVar(value=0)
        power_slider = ttk.Scale(control_frame, from_=0, to=100, variable=self.power_var,
                               command=lambda v: self.power_label.config(text=f"{int(float(v))}%"))
        power_slider.grid(row=0, column=1, padx=5, sticky='ew')
        self.power_label = ttk.Label(control_frame, text="0%")
        self.power_label.grid(row=0, column=2, padx=5)
        
        # Boutons de contrôle
        ttk.Button(control_frame, text="Appliquer à tous", command=self.apply_power_all).grid(row=0, column=3, padx=5)
        ttk.Button(control_frame, text="Arrêter tout", command=self.stop_all).grid(row=0, column=4, padx=5)
        ttk.Button(control_frame, text="Générer JSON", command=self.show_json).grid(row=0, column=5, padx=5)
        
        # Cellule de publication
        ttk.Label(control_frame, text="Cellule de publication:").grid(row=1, column=0, padx=5, pady=5)
        self.publish_var = tk.StringVar(value=str(self.publish_cell))
        ttk.Entry(control_frame, textvariable=self.publish_var, width=5).grid(row=1, column=1, padx=5, sticky='w')
    
    def create_square_grid(self, parent):
        """Crée une grille carrée compacte des cellules"""
        for row in range(self.grid_size):
            for col in range(self.grid_size):
                cell_id = f"{row+1}{col+1}"
                cell_frame = ttk.LabelFrame(parent, text=f"Cell {cell_id}", 
                                          style='Cell.TLabelframe', padding=3)
                cell_frame.grid(row=row, column=col, padx=2, pady=2, sticky="nsew")
                
                # Configurer le poids des lignes/colonnes pour un carré parfait
                parent.grid_rowconfigure(row, weight=1, uniform="cells")
                parent.grid_columnconfigure(col, weight=1, uniform="cells")
                
                # Créer les 9 ventilateurs (3x3) dans chaque cellule
                self.create_fans_in_cell(cell_frame, cell_id)
    
    def create_fans_in_cell(self, parent, cell_id):
        """Crée les 9 ventilateurs dans une cellule"""
        for fan_row in range(3):
            for fan_col in range(3):
                fan_idx = fan_row * 3 + fan_col
                btn = tk.Button(parent, width=2, height=1, font=('Helvetica', 7),
                              command=lambda cid=cell_id, fidx=fan_idx: self.select_fan(cid, fidx))
                btn.grid(row=fan_row, column=fan_col, padx=1, pady=1, sticky="nsew")
                
                # Configurer le poids pour un affichage uniforme
                parent.grid_rowconfigure(fan_row, weight=1, uniform="fans")
                parent.grid_columnconfigure(fan_col, weight=1, uniform="fans")
                
                # Stocker la référence au bouton
                self.fan_status[cell_id][f"btn_{fan_idx}"] = btn
                btn.config(text="0%")
    
    def select_fan(self, cell_id, fan_idx):
        """Sélectionne un ventilateur spécifique"""
        power = self.fan_status[cell_id]['power'][fan_idx]
        self.power_var.set(power)
        print(f"Ventilateur sélectionné: Cellule {cell_id}, Ventilateur {fan_idx//3+1}{fan_idx%3+1} (Puissance: {power}%)")
    
    def apply_power_all(self):
        """Applique la puissance à tous les ventilateurs"""
        power = self.power_var.get()
        for cell_id in self.fan_status:
            for i in range(9):
                self.fan_status[cell_id]['power'][i] = power
                btn = self.fan_status[cell_id][f"btn_{i}"]
                btn.config(text=f"{power}%")
                self.update_button_style(btn, power)
        
        self.generate_command_json()
        print(f"Puissance appliquée: {power}% à tous les ventilateurs")
    
    def update_button_style(self, button, power):
        """Met à jour le style du bouton en fonction de la puissance"""
        if power > 0:
            button.config(bg="#4CAF50", fg="white")  # Vert
        else:
            button.config(bg="SystemButtonFace", fg="black")
    
    def stop_all(self):
        """Arrête tous les ventilateurs"""
        self.power_var.set(0)
        self.apply_power_all()
        print("Tous les ventilateurs arrêtés")
    
    def generate_command_json(self):
        """Génère le JSON de commande"""
        command_data = {}
        for cell_id in self.fan_status:
            command_data[cell_id] = self.fan_status[cell_id]['power']
        
        command_data["Publish"] = int(self.publish_var.get())
        self.command_json = json.dumps(command_data, indent=2)
        return self.command_json
    
    def show_json(self):
        """Affiche le JSON généré"""
        json_win = tk.Toplevel(self.root)
        json_win.title("JSON de Commande")
        json_win.geometry("600x400")
        
        txt = tk.Text(json_win, wrap=tk.WORD, width=80, height=25)
        txt.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        txt.insert(tk.END, self.generate_command_json())
        txt.config(state=tk.DISABLED)
        
        ttk.Button(json_win, text="Fermer", command=json_win.destroy).pack(pady=5)
    
    def update_rpm_data(self):
        """Simule la mise à jour des données RPM"""
        while True:
            for cell_id in self.fan_status:
                for i in range(9):
                    if self.fan_status[cell_id]['power'][i] > 0:
                        base_rpm = self.fan_status[cell_id]['power'][i] * 10
                        self.fan_status[cell_id]['rpm'][i] = base_rpm + random.randint(-50, 50)
                    else:
                        self.fan_status[cell_id]['rpm'][i] = 0
            
            time.sleep(0.1)

if __name__ == "__main__":
    root = tk.Tk()
    app = GVMControlApp(root)
    root.mainloop()