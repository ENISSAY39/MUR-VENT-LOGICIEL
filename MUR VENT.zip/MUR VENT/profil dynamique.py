import tkinter as tk
from tkinter import ttk
import json
import threading
import time
import random

def open_wind_profile_window(self):
        self.wind_profile_window = tk.Toplevel(self.root)
        self.wind_profile_window.title("Profil de Vent Dynamique")

        self.wind_sequences = []

        # Liste des séquences
        self.sequence_listbox = tk.Listbox(self.wind_profile_window, height=10, width=50)
        self.sequence_listbox.pack(padx=10, pady=10)

        # Entrée pour puissance et durée
        input_frame = ttk.Frame(self.wind_profile_window)
        input_frame.pack(pady=5)

        ttk.Label(input_frame, text="Puissance (%)").grid(row=0, column=0, padx=5)
        self.profile_power = tk.IntVar()
        ttk.Entry(input_frame, textvariable=self.profile_power, width=5).grid(row=0, column=1, padx=5)

        ttk.Label(input_frame, text="Durée (s)").grid(row=0, column=2, padx=5)
        self.profile_duration = tk.IntVar()
        ttk.Entry(input_frame, textvariable=self.profile_duration, width=5).grid(row=0, column=3, padx=5)

        ttk.Button(self.wind_profile_window, text="Ajouter séquence", command=self.add_wind_sequence).pack(pady=5)

        ttk.Button(self.wind_profile_window, text="Lancer le profil dynamique", command=self.start_wind_profile).pack(pady=10)
