import tkinter as tk
from tkinter import ttk, messagebox
import json
import threading
import time
import random

class GVMControlApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Contrôle GVM - Interface de Contrôle des Ventilateurs")
        
        self.grid_rows = 3
        self.grid_cols = 3
        self.cell_size = 60
        self.fan_status = {}
        self.publish_cell = 24
        
        # Liste des ventilateurs sélectionnés, chaque élément est (cell_id, fan_idx)
        self.selected_fans = set()
        
        self.initialize_fan_data()
        self.create_widgets()
        
        self.update_thread = threading.Thread(target=self.update_rpm_data, daemon=True)
        self.update_thread.start()
    
    def initialize_fan_data(self):
        for cell_row in range(1, self.grid_rows + 1):
            for cell_col in range(1, self.grid_cols + 1):
                cell_id = f"{cell_row}{cell_col}"
                self.fan_status[cell_id] = {
                    'power': [0] * 9,
                    'rpm': [0] * 9,
                    'active': False,
                    'functional': True
                }

    def create_widgets(self):
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        self.create_fan_grid(main_frame)
        
        control_frame = ttk.Frame(main_frame)
        control_frame.pack(fill=tk.X, pady=10)
        
        ttk.Label(control_frame, text="Puissance (%):").grid(row=0, column=0, padx=5)
        self.power_var = tk.IntVar(value=0)
        power_slider = ttk.Scale(control_frame, from_=0, to=100, variable=self.power_var, 
                                command=lambda v: self.power_label.config(text=f"{int(float(v))}%"))
        power_slider.grid(row=0, column=1, padx=5)
        self.power_label = ttk.Label(control_frame, text="0%")
        self.power_label.grid(row=0, column=2, padx=5)
        
        ttk.Button(control_frame, text="Appliquer", command=self.apply_power_selected).grid(row=0, column=3, padx=5)
        ttk.Button(control_frame, text="Arrêter tout", command=self.stop_all).grid(row=0, column=4, padx=5)
        ttk.Button(control_frame, text="Générer JSON", command=self.show_json).grid(row=0, column=5, padx=5)
        
        ttk.Label(control_frame, text="Cellule de publication:").grid(row=1, column=0, padx=5, pady=5)
        self.publish_var = tk.StringVar(value=str(self.publish_cell))
        ttk.Entry(control_frame, textvariable=self.publish_var, width=5).grid(row=1, column=1, padx=5)
        
        self.status_console = tk.Text(main_frame, height=10, state=tk.DISABLED)
        self.status_console.pack(fill=tk.BOTH, expand=True, pady=10)
        
        scrollbar = ttk.Scrollbar(self.status_console)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.status_console.config(yscrollcommand=scrollbar.set)
        scrollbar.config(command=self.status_console.yview)
    
    def create_fan_grid(self, parent):
        grid_frame = ttk.Frame(parent)
        grid_frame.pack(fill=tk.BOTH, expand=True)
        
        for cell_row in range(1, self.grid_rows + 1):
            for cell_col in range(1, self.grid_cols + 1):
                cell_id = f"{cell_row}{cell_col}"
                cell_frame = ttk.LabelFrame(grid_frame, text=f"Cell {cell_id}", padding="5")
                cell_frame.grid(row=cell_row-1, column=cell_col-1, padx=2, pady=2, sticky="nsew")
                
                for fan_row in range(3):
                    for fan_col in range(3):
                        fan_idx = fan_row * 3 + fan_col
                        fan_btn = tk.Button(cell_frame, text="0%", width=4, height=2,
                                            command=lambda cid=cell_id, fi=fan_idx: self.toggle_select_fan(cid, fi))
                        fan_btn.grid(row=fan_row, column=fan_col, padx=1, pady=1)
                        self.fan_status[cell_id][f"btn_{fan_idx}"] = fan_btn
    
    def toggle_select_fan(self, cell_id, fan_idx):
        key = (cell_id, fan_idx)
        if key in self.selected_fans:
            self.selected_fans.remove(key)
            # Remet la couleur normale selon puissance
            power = self.fan_status[cell_id]['power'][fan_idx]
            btn = self.fan_status[cell_id][f"btn_{fan_idx}"]
            if power > 0:
                btn.config(bg="green", fg="white")
            else:
                btn.config(bg="SystemButtonFace", fg="black")
            self.log_status(f"Désélectionné: Cellule {cell_id} Ventilateur {fan_idx+1}")
        else:
            self.selected_fans.add(key)
            btn = self.fan_status[cell_id][f"btn_{fan_idx}"]
            btn.config(bg="blue", fg="white")
            self.log_status(f"Sélectionné: Cellule {cell_id} Ventilateur {fan_idx+1}")
    
    def apply_power_selected(self):
        power = self.power_var.get()
        if not self.selected_fans:
            messagebox.showwarning("Aucun ventilateur sélectionné", "Veuillez sélectionner au moins un ventilateur.")
            return
        
        for cell_id, fan_idx in self.selected_fans:
            self.fan_status[cell_id]['power'][fan_idx] = power
            btn = self.fan_status[cell_id][f"btn_{fan_idx}"]
            # Garder la surbrillance bleue si sélectionné, sinon vert ou normal
            btn.config(text=f"{power}%", fg="white")
            if (cell_id, fan_idx) in self.selected_fans:
                btn.config(bg="blue")
            else:
                btn.config(bg="green" if power > 0 else "SystemButtonFace")
        
        self.generate_command_json()
        self.log_status(f"Puissance appliquée: {power}% aux ventilateurs sélectionnés")
    
    def stop_all(self):
        self.power_var.set(0)
        for cell_id in self.fan_status:
            for i in range(9):
                self.fan_status[cell_id]['power'][i] = 0
                btn = self.fan_status[cell_id][f"btn_{i}"]
                btn.config(text="0%", bg="SystemButtonFace", fg="black")
        self.selected_fans.clear()
        self.generate_command_json()
        self.log_status("Tous les ventilateurs arrêtés et désélectionnés")
    
    def generate_command_json(self):
        command_data = {}
        for cell_id in self.fan_status:
            command_data[cell_id] = self.fan_status[cell_id]['power']
        command_data["Publish"] = int(self.publish_var.get())
        self.command_json = json.dumps(command_data, indent=2)
        return self.command_json
    
    def show_json(self):
        json_win = tk.Toplevel(self.root)
        json_win.title("JSON de Commande")
        
        txt = tk.Text(json_win, wrap=tk.WORD, width=60, height=20)
        txt.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        json_data = self.generate_command_json()
        txt.insert(tk.END, json_data)
        txt.config(state=tk.DISABLED)
        
        ttk.Button(json_win, text="Fermer", command=json_win.destroy).pack(pady=5)
    
    def update_rpm_data(self):
        while True:
            for cell_id in self.fan_status:
                for i in range(9):
                    if self.fan_status[cell_id]['power'][i] > 0:
                        base_rpm = self.fan_status[cell_id]['power'][i] * 10
                        self.fan_status[cell_id]['rpm'][i] = base_rpm + random.randint(-50, 50)
                    else:
                        self.fan_status[cell_id]['rpm'][i] = 0
            
            self.generate_response_json()
            self.root.after(100, self.update_ui_with_rpm)
            time.sleep(1)
    
    def generate_response_json(self):
        sample_cell = random.choice(list(self.fan_status.keys()))
        response_data = {
            "cell": int(sample_cell),
            "RPM": self.fan_status[sample_cell]['rpm']
        }
        self.response_json = json.dumps(response_data, indent=2)
        return self.response_json
    
    def update_ui_with_rpm(self):
        sample_cell = random.choice(list(self.fan_status.keys()))
        sample_fan = random.randint(0, 8)
        
        rpm = self.fan_status[sample_cell]['rpm'][sample_fan]
        power = self.fan_status[sample_cell]['power'][sample_fan]
        
        tolerance = 500
        expected_rpm = power * 10
        is_functional = abs(rpm - expected_rpm) <= tolerance
        
        self.fan_status[sample_cell]['functional'] = is_functional
        
        btn = self.fan_status[sample_cell][f"btn_{sample_fan}"]
        if power > 0:
            # Si ventilateur sélectionné, garder bleu, sinon vert ou rouge
            if (sample_cell, sample_fan) in self.selected_fans:
                btn.config(bg="blue", fg="white")
            else:
                btn.config(bg="green" if is_functional else "red", fg="white")
        
        self.log_status(f"Cellule {sample_cell} Vent.{sample_fan+1}: Consigne={power}%, RPM={rpm}, OK={is_functional}")
    
    def log_status(self, message):
        self.status_console.config(state=tk.NORMAL)
        self.status_console.insert(tk.END, message + "\n")
        self.status_console.see(tk.END)
        self.status_console.config(state=tk.DISABLED)

if __name__ == "__main__":
    root = tk.Tk()
    app = GVMControlApp(root)
    root.mainloop()
